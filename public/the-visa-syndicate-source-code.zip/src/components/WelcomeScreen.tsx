import React, { useState } from 'react';
import { BrandLogo } from './BrandLogo';
import {
  ArrowRight,
  GraduationCap,
  Plane,
  Briefcase,
  ShieldCheck,
  Compass,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface WelcomeScreenProps {
  onEnter: (category?: 'study' | 'visit' | 'business') => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onEnter }) => {
  const [selectedPathway, setSelectedPathway] = useState<'study' | 'visit' | 'business' | null>(null);
  const [isEntering, setIsEntering] = useState(false);

  const handleStart = (pathway?: 'study' | 'visit' | 'business') => {
    setIsEntering(true);
    setTimeout(() => {
      onEnter(pathway || selectedPathway || undefined);
    }, 450);
  };

  return (
    <div
      className={`fixed inset-0 z-50 overflow-y-auto bg-gradient-to-br from-[#1C0306] via-[#3B070D] to-[#140204] text-white flex flex-col justify-between transition-all duration-500 ${
        isEntering ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Ambient Radial Lights & Glowing Backdrop Particles */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(200,16,30,0.25),transparent_60%)] pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#C8101E]/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Bar */}
      <header className="relative z-10 max-w-7xl mx-auto w-full px-6 py-6 flex items-center justify-between">
        <BrandLogo variant="light" size="sm" />
        <button
          onClick={() => handleStart()}
          className="text-xs uppercase tracking-widest text-white/60 hover:text-white px-3 py-1.5 rounded-full border border-white/10 hover:border-white/30 transition-all cursor-pointer"
        >
          Skip Intro →
        </button>
      </header>

      {/* Main Hero Hook Section */}
      <main className="relative z-10 max-w-4xl mx-auto w-full px-6 py-8 text-center my-auto flex flex-col items-center">
        {/* Animated Floating Emblem Badge */}
        <div className="relative mb-6">
          <div className="absolute -inset-4 bg-[#C8101E]/30 rounded-full blur-xl animate-pulse"></div>
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-b from-[#760B16] to-[#C8101E] border-2 border-white/20 shadow-2xl flex items-center justify-center p-3">
            <BrandLogo variant="emblem" size="lg" />
          </div>
        </div>

        {/* Hook Eyebrow */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-semibold uppercase tracking-widest text-rose-200 mb-4 animate-in fade-in duration-500">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Institutional Visa Advisory & Case Audits</span>
        </div>

        {/* Grand Headline */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif-brand font-bold tracking-tight text-white leading-tight max-w-3xl">
          Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-rose-100 to-amber-200">The Visa Syndicate</span>
        </h1>

        <p className="mt-2 text-xl sm:text-2xl font-serif-brand italic text-rose-200/90 font-light">
          Your Next Chapter Starts With Clarity.
        </p>

        {/* Hook Subtitle */}
        <p className="mt-4 text-xs sm:text-sm text-white/70 max-w-2xl leading-relaxed">
          Navigate foreign High Commission requirements with absolute statutory confidence. Meticulously audited financial holdings, genuine university admissions, and expert counselor backing for the UK, Canada, USA, Australia, and Schengen.
        </p>

        {/* 3 Pathway Cards (Select to Jump Directly) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 w-full max-w-2xl mt-8">
          {[
            {
              id: 'study' as const,
              title: 'Study Visa',
              desc: 'Admissions, CAS/I-20 & 28-Day Bank Vetting',
              icon: GraduationCap,
              color: 'from-rose-500/20 to-red-950/40',
            },
            {
              id: 'visit' as const,
              title: 'Visit Visa',
              desc: 'Tourism, Family Ties & Solid Return Incentives',
              icon: Plane,
              color: 'from-amber-500/20 to-red-950/40',
            },
            {
              id: 'business' as const,
              title: 'Business Visa',
              desc: 'Trade Delegations & Commercial Sponsorship',
              icon: Briefcase,
              color: 'from-indigo-500/20 to-red-950/40',
            },
          ].map((item) => {
            const Icon = item.icon;
            const isSelected = selectedPathway === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setSelectedPathway(item.id)}
                className={`p-4 rounded-2xl border text-left transition-all duration-300 cursor-pointer backdrop-blur-md relative overflow-hidden group ${
                  isSelected
                    ? 'border-[#C8101E] bg-[#C8101E]/30 ring-2 ring-[#C8101E]/50 shadow-lg scale-102'
                    : 'border-white/10 hover:border-white/30 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-rose-300 group-hover:scale-110 transition-transform">
                    <Icon className="w-4 h-4" />
                  </div>
                  {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                </div>
                <h3 className="font-bold text-sm text-white">{item.title}</h3>
                <p className="text-[11px] text-white/60 mt-1 leading-snug">{item.desc}</p>
              </button>
            );
          })}
        </div>

        {/* Enter CTA Button */}
        <div className="mt-8 flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={() => handleStart()}
            className="px-9 py-4 bg-gradient-to-r from-[#C8101E] to-[#E31B2F] hover:from-[#760B16] hover:to-[#C8101E] text-white text-sm font-bold rounded-full shadow-2xl hover:shadow-[0_0_35px_rgba(200,16,30,0.6)] transition-all duration-300 flex items-center gap-3 cursor-pointer transform hover:-translate-y-0.5"
          >
            <span>{selectedPathway ? `Explore ${selectedPathway.toUpperCase()} Pathway` : 'Enter The Experience'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Trust Badges */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-[11px] text-white/50">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Direct High Commission Auditing</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-amber-300" />
            <span>UK · Canada · USA · Aus · Schengen</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-rose-300" />
            <span>Certified Legal Counselors</span>
          </div>
        </div>
      </main>

      {/* Footer Strip */}
      <footer className="relative z-10 max-w-7xl mx-auto w-full px-6 py-4 flex flex-col sm:flex-row items-center justify-between text-[11px] text-white/40 border-t border-white/10">
        <span>© {new Date().getFullYear()} The Visa Syndicate. All rights reserved.</span>
        <span>Secure Consultation Desk · SadaPay Verified</span>
      </footer>
    </div>
  );
};
