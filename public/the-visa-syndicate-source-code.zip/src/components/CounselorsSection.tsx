import React, { useState, useEffect } from 'react';
import { api, PublicCounselor } from '../lib/api';
import {
  UserCheck,
  Calendar,
  Clock,
  Globe2,
  Languages,
  ArrowRight,
  ShieldAlert,
  Sparkles,
  RefreshCw,
} from 'lucide-react';

interface CounselorsSectionProps {
  onBookWithCounselor: (counselor?: PublicCounselor) => void;
  onOpenEligibility: () => void;
}

export const CounselorsSection: React.FC<CounselorsSectionProps> = ({
  onBookWithCounselor,
  onOpenEligibility,
}) => {
  const [counselors, setCounselors] = useState<PublicCounselor[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState<string>('All');

  const fetchCounselors = async () => {
    setLoading(true);
    try {
      const data = await api.getPublicCounselors();
      setCounselors(data);
    } catch (err) {
      console.error('Failed to load public counselors:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCounselors();
  }, []);

  const filteredCounselors = counselors.filter((c) => {
    if (selectedFilter === 'All') return true;
    return (
      c.destinations.includes(selectedFilter) ||
      c.visaCategories.some((v) => v.toLowerCase().includes(selectedFilter.toLowerCase()))
    );
  });

  return (
    <section id="counselors" className="py-16 sm:py-24 bg-[#FAF8F6] border-t border-[#E9DAD9]/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#C8101E]"></span>
              <span className="text-xs font-bold tracking-widest text-[#760B16] uppercase">
                ACCREDITED ADVISORY PANEL
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif-brand font-bold text-[#202124]">
              Meet Our Verified Visa Counselors
            </h2>
            <p className="text-[#6B7078] text-sm sm:text-base leading-relaxed">
              Book one-on-one virtual or in-person consultation sessions with verified specialists. Every
              counselor profile is independently audited and managed through our centralized accreditation system.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchCounselors}
              className="p-2.5 bg-white border border-[#E9DAD9] hover:bg-[#F1EEEC] text-[#6B7078] rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Refresh roster"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-[#C8101E]' : ''}`} />
              <span className="hidden sm:inline">Sync Roster</span>
            </button>
            <button
              onClick={() => onBookWithCounselor(undefined)}
              className="px-5 py-2.5 bg-[#C8101E] hover:bg-[#760B16] text-white text-xs sm:text-sm font-semibold rounded-full shadow-sm hover:shadow transition-colors cursor-pointer"
            >
              General Consultation
            </button>
          </div>
        </div>

        {/* Filter Bar (if counselors exist) */}
        {counselors.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 mb-8 p-1.5 bg-white rounded-2xl border border-[#E9DAD9] max-w-fit shadow-2xs">
            {['All', 'UK', 'Canada', 'USA', 'Australia', 'Europe', 'Study', 'Visit'].map((filter) => (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                  selectedFilter === filter
                    ? 'bg-[#C8101E] text-white shadow-xs'
                    : 'text-[#6B7078] hover:text-[#202124] hover:bg-[#FAF8F6]'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-6 border border-[#E9DAD9] shadow-2xs animate-pulse space-y-4"
              >
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-slate-200"></div>
                  <div className="space-y-2 flex-1">
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                    <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                  </div>
                </div>
                <div className="h-12 bg-slate-200 rounded"></div>
                <div className="h-8 bg-slate-200 rounded w-full"></div>
              </div>
            ))}
          </div>
        )}

        {/* STRICT EMPTY STATE: Displayed when DB contains 0 published counselors */}
        {!loading && counselors.length === 0 && (
          <div className="bg-white rounded-3xl p-8 sm:p-12 border border-[#E9DAD9] shadow-sm text-center max-w-3xl mx-auto space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-[#C8101E]/10 text-[#C8101E] flex items-center justify-center mx-auto">
              <UserCheck className="w-8 h-8" />
            </div>

            <div className="space-y-2 max-w-lg mx-auto">
              <h3 className="text-xl sm:text-2xl font-serif-brand font-bold text-[#202124]">
                Advisory Roster Currently Updating
              </h3>
              <p className="text-sm text-[#6B7078] leading-relaxed">
                In strict accordance with our verified credentials policy, public counselor profiles are
                published only following direct administrative credential vetting and roster publication.
              </p>
            </div>

            {/* Explanatory Banner */}
            <div className="bg-[#FAF8F6] rounded-2xl p-4 sm:p-5 border border-[#E9DAD9] text-left text-xs text-[#202124] space-y-2 max-w-xl mx-auto">
              <div className="flex items-center gap-2 font-bold text-[#760B16]">
                <ShieldAlert className="w-4 h-4 text-[#C8101E]" />
                <span>Zero Fictional Profile Guarantee</span>
              </div>
              <p className="text-[#6B7078] text-xs">
                The Visa Syndicate does not display placeholder or fictional counselors. You can proceed with a
                centralized case evaluation through our Senior Advisory Panel, or log into the administrator console
                to publish certified counselors.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                onClick={() => onBookWithCounselor(undefined)}
                className="px-6 py-3 bg-[#C8101E] hover:bg-[#760B16] text-white text-xs sm:text-sm font-semibold rounded-full shadow-sm hover:shadow transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Book General Advisory Session</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={onOpenEligibility}
                className="px-6 py-3 bg-white hover:bg-[#FAF8F6] text-[#202124] border border-[#E9DAD9] text-xs sm:text-sm font-semibold rounded-full transition-colors cursor-pointer"
              >
                Free Eligibility Assessment
              </button>
            </div>
          </div>
        )}

        {/* Counselors Grid (when published by admin) */}
        {!loading && filteredCounselors.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCounselors.map((counselor) => (
              <div
                key={counselor.id}
                className="bg-white rounded-2xl p-6 border border-[#E9DAD9] shadow-2xs hover:shadow-md transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Counselor Top Header */}
                  <div className="flex items-start gap-4">
                    <div className="relative w-16 h-16 rounded-full overflow-hidden bg-[#FAF8F6] border-2 border-[#E9DAD9] shrink-0">
                      {counselor.photoUrl ? (
                        <img
                          src={counselor.photoUrl}
                          alt={counselor.displayName}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-lg font-bold text-[#C8101E] bg-[#C8101E]/10">
                          {counselor.displayName.charAt(0)}
                        </div>
                      )}
                      {counselor.isFeatured && (
                        <div
                          className="absolute -bottom-1 -right-1 bg-[#C8101E] text-white p-1 rounded-full shadow-xs"
                          title="Featured Counselor"
                        >
                          <Sparkles className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-bold text-[#202124] group-hover:text-[#C8101E] transition-colors truncate">
                        {counselor.displayName}
                      </h3>
                      <p className="text-xs font-medium text-[#760B16] mt-0.5 truncate">
                        {counselor.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1.5 text-[11px] text-[#6B7078]">
                        <span>{counselor.experienceYears}+ Years Exp.</span>
                        <span>·</span>
                        <span>{counselor.consultationDuration} min session</span>
                      </div>
                    </div>
                  </div>

                  {/* Biography */}
                  <p className="text-xs text-[#6B7078] line-clamp-3 leading-relaxed">
                    {counselor.bio || 'Specialist in student visa applications, financial documentation audits, and embassy interview coaching.'}
                  </p>

                  {/* Destinations & Visa Types */}
                  <div className="space-y-2 pt-2 border-t border-[#F1EEEC]">
                    <div className="flex items-center gap-1.5 text-xs text-[#202124]">
                      <Globe2 className="w-3.5 h-3.5 text-[#C8101E] shrink-0" />
                      <span className="font-semibold text-[11px]">Destinations:</span>
                      <span className="text-[11px] text-[#6B7078] truncate">
                        {counselor.destinations.join(', ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-[#202124]">
                      <Languages className="w-3.5 h-3.5 text-[#C8101E] shrink-0" />
                      <span className="font-semibold text-[11px]">Languages:</span>
                      <span className="text-[11px] text-[#6B7078] truncate">
                        {counselor.languages.join(', ')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Card Footer with Fee and Booking CTA */}
                <div className="pt-4 mt-4 border-t border-[#E9DAD9] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-[#6B7078] uppercase font-semibold block leading-none">
                      Consultation Fee
                    </span>
                    <span className="text-base font-bold text-[#202124] font-mono">
                      PKR {counselor.consultationFee.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => onBookWithCounselor(counselor)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#C8101E] hover:bg-[#760B16] text-white text-xs font-semibold rounded-full shadow-2xs hover:shadow transition-colors cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Book Session</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
